## Tableau Visualization

***1. Student Registered per Module Over 2 Year***

![image](https://user-images.githubusercontent.com/83144665/149415003-273c5ce7-6999-47c6-895c-49eb7fa3af5d.png)
- Visual: Stacked Bar Chart
This visual illustrates the student registerted across 2013B, 2013J, 2014B, 2014J. We could see that presentaions starts at October have the higher number of student registered. Different color of the bar representing the propotion of module that students registered in different presentaion.



***2. Student Registered per Age and Highest Education***

![image](https://user-images.githubusercontent.com/83144665/149416613-2788d1fd-77ac-4dd9-bbda-0dba1eeabb1d.png)

- Visual: Stacked Bar Chart

This visual illustrates the distribution of students registered in education level, age band, and also whether or not a disability. It clearly shows that most of the student registered are not disability and at age 0-35 range. The highest education background the students have are A level or Equivatlent, and  lower than A level. No student with a disability at age >=55 range. Also, the proportion of female and male students are half and half.



***3. Student Registered per Region per Module***

![image](https://user-images.githubusercontent.com/83144665/149418224-b6cdfa3c-1efc-44d1-ad9d-a5ac4569c638.png)

- Visual: Heat Map

This visual illustruates the distribution of students registered in different region and module. Darker color means more student in that region and module, lighter colors means the fewer. From geographical perspective, Ireland has the fewer students registered. From module perspective, BBB, DDD, and FFF has the most students registered while AAA has the least. According to the first bar chart, it could be reason why AAA module only open in 2013J and 2014J while BBB, DDD and FFF open in all presentaion. 



***4. Number of Student per Registration Result***

![image](https://user-images.githubusercontent.com/83144665/149419569-9e9a42a7-6c77-4325-b988-26da7060face.png)

- Visual: Packed Bubbles

This Visuals simply represents the registration result in terms of the szie of the bubbles. Larger bubbles, more students fall into that category. We could see that the majority pass their registration, at the same time, a lot pf student withdrawn even before they start the presentation and assessment. WE need to find out the reason why student withdrawn from the registration and use different strategy to attract student to continue on the registration process.
